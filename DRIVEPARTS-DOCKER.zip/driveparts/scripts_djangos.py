shell = "python manage.py shell_plus --print-sql"
migr = 'python manage.py makemigrations&python manage.py migrate'
migr = 0