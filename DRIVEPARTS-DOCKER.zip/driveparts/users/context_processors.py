from goods.utils import test

def get_goods_context(request):
    return {'test': test}