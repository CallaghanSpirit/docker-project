# Для добавления классов Mixin

test = 'ТЕСТ'
class DataMixin:
   paginate_by = 2